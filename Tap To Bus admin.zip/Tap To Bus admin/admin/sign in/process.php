<?php
if(empty($_POST["username"])){
    die("Username is required");
}

print_r($_POST);
